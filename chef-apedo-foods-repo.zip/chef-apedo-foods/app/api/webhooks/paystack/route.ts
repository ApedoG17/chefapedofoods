import { NextResponse } from "next/server";
import crypto from "node:crypto";

/**
 * POST /api/webhooks/paystack
 *
 * THE rule this route exists to enforce (docs/ARCHITECTURE.md payment
 * flow, docs/SECURITY.md, docs/AGENTS.md):
 *
 *   An order is marked `confirmed` ONLY after this webhook verifies a
 *   successful payment. Never mark an order confirmed because the
 *   browser/client says payment succeeded.
 *
 * Steps (per Paystack's docs — verify before implementing against the
 * real dashboard/secret key):
 *   1. Verify the `x-paystack-signature` header against a HMAC-SHA512 of
 *      the raw request body, using the Paystack secret key.
 *   2. Reject (400) if the signature doesn't match — do not process the
 *      payload.
 *   3. On a verified `charge.success` event, look up the order by the
 *      Paystack reference and set payment_status='paid',
 *      order_status='confirmed'.
 *   4. Respond 200 quickly; do any slow work (notifications) after.
 */
export async function POST(request: Request) {
  const rawBody = await request.text();
  const signature = request.headers.get("x-paystack-signature");

  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) {
    return NextResponse.json({ error: "Server misconfigured" }, { status: 500 });
  }

  const expectedSignature = crypto
    .createHmac("sha512", secret)
    .update(rawBody)
    .digest("hex");

  if (signature !== expectedSignature) {
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  // TODO: parse rawBody as JSON, check event === "charge.success",
  // look up the order by reference, and update it server-side via
  // lib/orders — implement once the schema is migrated.

  return NextResponse.json({ received: true });
}
