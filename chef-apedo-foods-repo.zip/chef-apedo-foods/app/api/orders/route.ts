import { NextResponse } from "next/server";

/**
 * POST /api/orders — creates an order in `awaiting_payment` status.
 *
 * Server-side rules to enforce here (per docs/PRD.md §10 and RULES.md —
 * do not duplicate these checks in the client, only reflect them there):
 *   1. Kitchen must be open (kitchen_settings.open)
 *   2. Daily capacity not yet reached (kitchen_settings.orders_today < daily_capacity)
 *   3. Requested delivery slot/time is before the same-day cutoff, or a
 *      valid future slot
 *   4. Delivery area is not in EXCLUDED_DELIVERY_AREAS / matches an active
 *      DeliveryZone
 *   5. All selected meal/size/protein/extra combinations are `available`
 *   6. Price is recalculated server-side (lib/pricing) — never trust a
 *      client-submitted total
 *
 * TODO: implement against the real schema once migrated.
 */
export async function POST(_request: Request) {
  return NextResponse.json(
    { error: "Not implemented yet — see TODO in app/api/orders/route.ts" },
    { status: 501 }
  );
}
