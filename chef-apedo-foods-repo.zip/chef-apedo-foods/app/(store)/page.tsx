// Home — see docs/PRD.md §"Sitemap" and docs/COMPONENTS.md for the
// locked content/components (Hero, Meal Card grid, How It Works, etc.)
// This is a scaffold placeholder, not the final implementation.

export default function HomePage() {
  return (
    <main className="max-w-md mx-auto px-5 py-8">
      <p className="text-gold text-[10px] tracking-[0.14em] uppercase mb-2">
        Chef Apedo Foods
      </p>
      <h1 className="font-serif text-2xl font-semibold mb-2">
        Authentic Ghanaian meals, made with care.
      </h1>
      <p className="text-ink-dim text-sm">
        Freshly prepared and delivered straight to your doorstep.
      </p>
      {/* TODO: Hero CTA row, Featured Meals grid (MealCard component),
          How It Works, Why Chef Apedo Foods, Delivery banner — see
          docs/COMPONENTS.md for exact anatomy of each. */}
    </main>
  );
}
