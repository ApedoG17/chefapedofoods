// Menu — fetches meals from Supabase (available=true) and renders MealCard
// per docs/COMPONENTS.md. Each Customize CTA routes to /menu/[mealId].
// TODO: replace with real Supabase query once the schema is migrated.

export default function MenuPage() {
  return (
    <main className="max-w-md mx-auto px-5 py-8">
      <h1 className="font-serif text-2xl font-semibold mb-4">
        Today&apos;s Menu
      </h1>
      {/* TODO: fetch meals + meal_sizes, render MealCard grid */}
    </main>
  );
}
