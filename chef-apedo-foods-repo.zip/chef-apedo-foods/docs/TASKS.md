# Chef Apedo Foods — Build Tasks

Ordered per the "core transaction first" decision in the planning doc (§27): don't start with the homepage — start with the screens that actually move money.

## 0. Pre-build decisions (blockers)

- [x] Choose frontend stack/framework — **Next.js + TypeScript + Tailwind CSS**
- [x] Choose payment integration — **Paystack** (covers MTN MoMo, Telecel, AirtelTigo, and card via one integration)
- [x] Choose hosting/backend — **Vercel (app) + Supabase (Postgres, Auth, Edge Functions, Storage)**
- [x] Set the actual daily order capacity to launch with — **12 orders/day**, configurable, expected to increase with experience
- [ ] Set real delivery-zone fees — **still genuinely open**; only the GH₵10 starting point and the excluded-area list are locked. The software model (admin-configurable `DeliveryZone` table) is built to support this once real dispatch economics are known — see `ARCHITECTURE.md`
- [ ] Finalize `RULES.md` stack-specific conventions — now that the stack is picked, do this before writing application code (§1 below)

## 1. Repository & data layer

- [ ] Scaffold the Next.js + TypeScript + Tailwind app (customer UI, admin UI, and API routes/server actions in one app, per `ARCHITECTURE.md`)
- [ ] Set up the Supabase project (Postgres, Auth, Edge Functions, Storage) and connect it to the app
- [ ] Set up the Paystack integration (test keys first) and the webhook endpoint for payment verification
- [ ] Implement the schema from `ARCHITECTURE.md` (Customer, Address, Meal, MealSize, ProteinOption, ProteinPackage, PackageItem, Order, OrderItem, OrderItemProtein, DeliveryZone, KitchenSettings)
- [ ] Seed the launch menu (3 meals × 3 sizes × included protein packages × extras, per `PRD.md`)
- [ ] Seed delivery zones and the excluded-area list (fee values pending — see §0)

## 2. Core transaction flow (build and test this before anything else)

- [ ] Meal Customization screen — size → included protein (scoped correctly per size) → extras → quantity → dynamic price
- [ ] Cart — items, modifiers, subtotal, delivery-location entry, serviceability check, fee calculation, pay-now/pay-rider split
- [ ] Checkout — customer details, delivery details, delivery-slot selection (respecting same-day cutoff and capacity)
- [ ] Payment — MoMo integration, payment breakdown, success/failure handling
- [ ] Order Confirmation — order number, summary, split payment display
- [ ] Order Status — lifecycle tracker, cancellation flow (deadline + preparation-status checks)

## 3. Kitchen/admin (brought forward, not Phase 3)

- [ ] Login (single chef account, no roles needed for MVP)
- [ ] Dashboard — today's snapshot, kitchen open/closed, capacity used
- [ ] Orders — list + filters by status
- [ ] Order Details — full order view, status-appropriate action buttons only
- [ ] Kitchen Controls — open/closed toggle, daily capacity setting, per-item/protein availability toggle

## 4. Marketing pages (designed around the working transaction, not before it)

- [ ] Home
- [ ] Menu (browse-only entry point into customization)
- [ ] How It Works
- [ ] About
- [ ] Delivery Information
- [ ] Contact

## 5. Testing

- [ ] Run the golden path end to end (see `TESTING.md`)
- [ ] Run all 7 edge-case scenarios (excluded location, post-cutoff order, closed kitchen, out-of-stock protein, cancellation, etc.)

## 6. Regulatory (parallel track, not blocking development)

- [ ] FDA Food Hygiene Permit — Online Food Business category
- [ ] GRA tax registration (Modified Taxation Scheme, informal-sector food vendor scope)
- [ ] Business Name registration via the Registrar of Companies
