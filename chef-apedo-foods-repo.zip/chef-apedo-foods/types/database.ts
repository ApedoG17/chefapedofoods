/**
 * Mirrors the schema in docs/ARCHITECTURE.md. Regenerate/adjust once the
 * real Supabase project exists (`supabase gen types typescript`), but keep
 * this hand-written version in sync in the meantime — RULES.md: no `any`
 * for order/payment/menu data.
 */

export type OrderStatus =
  | "awaiting_payment"
  | "confirmed"
  | "preparing"
  | "ready_for_dispatch"
  | "dispatched"
  | "delivered"
  | "cancelled";

export interface Customer {
  id: string;
  name: string;
  phone: string;
}

export interface Address {
  id: string;
  customer_id: string;
  address: string;
  area: string;
  delivery_zone_id: string;
}

export interface Meal {
  id: string;
  name: string;
  description: string | null;
  available: boolean;
}

export interface MealSize {
  id: string;
  meal_id: string;
  size: "small" | "medium" | "large";
  base_price_pesewas: number;
}

export interface ProteinOption {
  id: string;
  name: string;
  additional_price_pesewas: number;
  available: boolean;
}

export interface ProteinPackage {
  id: string;
  meal_size_id: string;
  name: string;
}

export interface PackageItem {
  package_id: string;
  protein_id: string;
  quantity: number;
}

export interface Order {
  id: string;
  customer_id: string;
  address_id: string;
  delivery_slot: string;
  subtotal_pesewas: number;
  delivery_fee_pesewas: number;
  amount_paid_pesewas: number;
  payment_method: "paystack";
  payment_status: "unpaid" | "paid" | "failed" | "refunded";
  order_status: OrderStatus;
  paystack_reference: string | null;
  created_at: string;
}

export interface OrderItem {
  id: string;
  order_id: string;
  meal_id: string;
  size_id: string;
  quantity: number;
  base_price_pesewas: number;
}

export interface OrderItemProtein {
  id: string;
  order_item_id: string;
  protein_id: string;
  quantity: number;
  additional_price_pesewas: number;
}

export interface DeliveryZone {
  id: string;
  name: string;
  areas: string[];
  fee_pesewas: number;
  active: boolean;
}

export interface KitchenSettings {
  id: string;
  open: boolean;
  daily_capacity: number;
  orders_today: number;
}

// Placeholder Database type for @supabase/ssr generics until the real
// generated types replace it.
export interface Database {
  public: {
    Tables: {
      customers: { Row: Customer };
      addresses: { Row: Address };
      meals: { Row: Meal };
      meal_sizes: { Row: MealSize };
      protein_options: { Row: ProteinOption };
      protein_packages: { Row: ProteinPackage };
      package_items: { Row: PackageItem };
      orders: { Row: Order };
      order_items: { Row: OrderItem };
      order_item_proteins: { Row: OrderItemProtein };
      delivery_zones: { Row: DeliveryZone };
      kitchen_settings: { Row: KitchenSettings };
    };
  };
}
