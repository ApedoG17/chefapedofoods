import { EXCLUDED_DELIVERY_AREAS } from "@/config/business";

export function isAreaServiceable(area: string): boolean {
  return !EXCLUDED_DELIVERY_AREAS.some(
    (excluded) => excluded.toLowerCase() === area.trim().toLowerCase()
  );
}

/**
 * Real per-zone fees are not yet set (see docs/TASKS.md §0) — this reads
 * from the DeliveryZone table (supabase/migrations) once seeded, rather
 * than a hard-coded map. Placeholder signature for the lookup:
 */
export interface DeliveryZone {
  id: string;
  name: string;
  areas: string[];
  feePesewas: number;
  active: boolean;
}

export async function getDeliveryFeeForArea(
  _area: string,
  _zones: DeliveryZone[]
): Promise<number | null> {
  // TODO: match area against active zones once real fee data is seeded.
  // Never return a hard-coded per-zone number here.
  throw new Error("Not implemented — seed DeliveryZone data first (docs/TASKS.md §0)");
}
