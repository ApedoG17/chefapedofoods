import type { Config } from "tailwindcss";

// Color tokens mirror docs/DESIGN_SYSTEM.md — update both together, per RULES.md.
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#17110D",
        surface: "#241A13",
        surface2: "#2C2117",
        line: "#3A2C1F",
        gold: "#C9A24C",
        "gold-soft": "#E7CE96",
        ink: "#F6EFE4",
        "ink-dim": "#B7AA98",
        "ink-on-cream": "#231A12",
        "bg-light": "#F6EFE4",
        ok: "#7FAE78",
        warn: "#D08277",
      },
      fontFamily: {
        serif: ["Fraunces", "serif"],
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      borderRadius: {
        card: "14px",
        pill: "9999px",
      },
    },
  },
  plugins: [],
};

export default config;
